<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

use App\Models\book_author;

class AuthorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      for($i=1; $i<=10; $i++){
      $user = book_author::create([
          'author_name' => 'author '.$i
      ]);
     }
    }
}
