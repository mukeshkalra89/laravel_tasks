<?php
use App\Models\book_author;

function get_authorName($authorId){
   $authorData = book_author::find($authorId);
   return $authorData->author_name;
}

 ?>
