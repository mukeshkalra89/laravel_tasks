<?php
namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\book_author;
use App\Models\Author_Book;
use Illuminate\Http\Request;

class BookController extends Controller

{

    /**

     * Display a listing of the resource.

     *

     * @return \Illuminate\Http\Response

     */

    function __construct()

    {

         $this->middleware('permission:book-list|book-create|book-edit|book-delete', ['only' => ['index','show']]);

         $this->middleware('permission:book-create', ['only' => ['create','store']]);

         $this->middleware('permission:book-edit', ['only' => ['edit','update']]);

         $this->middleware('permission:book-delete', ['only' => ['destroy']]);

    }

    /**

     * Display a listing of the resource.

     *

     * @return \Illuminate\Http\Response

     */

    public function index()

    {

        $books = Book::with('authors')->latest()->paginate(5);

        return view('books.index',compact('books'))

            ->with('i', (request()->input('page', 1) - 1) * 5);

    }



    /**

     * Show the form for creating a new resource.

     *

     * @return \Illuminate\Http\Response

     */

    public function create()

    {
        $authors = book_author::all();
        return view('books.create',compact('authors'));

    }



    /**

     * Store a newly created resource in storage.

     *

     * @param  \Illuminate\Http\Request  $request

     * @return \Illuminate\Http\Response

     */

    public function store(Request $request)

    {

        request()->validate([

            'name' => 'required',

            'detail' => 'required',

        ]);



        $book = Book::create($request->all());
        $book_id = $book->id;
        if($request->input('authors') && $book_id){
          $bookAuthorData =[];
          foreach($request->input('authors') as $authorId){
            $bookAuthorData[]=['book_id'=>$book_id,'author_id'=>$authorId];
          }
          Author_Book::insert($bookAuthorData);

          //dd($request->input('authors'));
        }

        return redirect()->route('books.index')

                        ->with('success','Book created successfully.');

    }



    /**

     * Display the specified resource.

     *

     * @param  \App\Book  $book

     * @return \Illuminate\Http\Response

     */

    public function show(Book $book)

    {

        return view('books.show',compact('book'));

    }



    /**

     * Show the form for editing the specified resource.

     *

     * @param  \App\Book  $book

     * @return \Illuminate\Http\Response

     */

    public function edit(Book $book)
    {

        return view('books.edit',compact('book'));

    }

    public function edit_book($bookId)
    {
        $book = Book::with('authors')->where('id','=',$bookId)->first();
        $authors = book_author::all();
        return view('books.edit',compact('book','authors'));

    }



    /**

     * Update the specified resource in storage.

     *

     * @param  \Illuminate\Http\Request  $request

     * @param  \App\Book  $book

     * @return \Illuminate\Http\Response

     */

    public function update(Request $request, Book $book)
    {

         request()->validate([

            'name' => 'required',

            'detail' => 'required',

        ]);


        //dd($book->id);
        $book->update($request->all());

        if($request->input('authors')){
          Author_Book::where('book_id',$book->id)->delete();
          $bookAuthorData =[];
          foreach($request->input('authors') as $authorId){
            $bookAuthorData[]=['book_id'=>$book->id,'author_id'=>$authorId];
          }
          Author_Book::insert($bookAuthorData);
        }

        return redirect()->route('books.index')

                        ->with('success','Book updated successfully');

    }


    /**

     * Remove the specified resource from storage.

     *

     * @param  \App\Book  $product

     * @return \Illuminate\Http\Response

     */

    public function destroy(Book $book)

    {

        $book->delete();



        return redirect()->route('books.index')

                        ->with('success','Book deleted successfully');

    }

}
