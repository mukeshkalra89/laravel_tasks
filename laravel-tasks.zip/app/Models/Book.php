<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    /**

     * The attributes that are mass assignable.

     *

     * @var array

     */
    protected $table = 'books';
    protected $fillable = [
        'name', 'detail'
    ];

    function authors(){
   	  return $this->hasMany('App\Models\Author_Book','book_id','id');
    }
}
